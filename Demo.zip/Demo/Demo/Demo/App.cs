﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace Demo
{
    public class App : Application
    {
        static INavigation CustomNavigaiton;

        public App()
        {
            // The root page of your application
            MainPage = new NavigationPage(new FirstPage());
            CustomNavigaiton = MainPage.Navigation;
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            var currentPage = CustomNavigaiton.NavigationStack.Last();

            if ((currentPage as FirstPage) != null)
            {
                var page = currentPage as FirstPage;
                //Calls the method in xaml.cs
                page.RefreshData();
                  
            }
            if((currentPage as SecondPage!=null))
            {   
                //This is for view Model RefreshData
                var page = currentPage as SecondPage;
                var viewModel = page.BindingContext as SecondPageViewModel;
                viewModel.RefreshData();
            }
        }
    }
}
